package edu.seg2105.edu.server.backend;

import java.io.IOException;
import java.util.Scanner;

import edu.seg2105.client.common.ChatIF;

public class ServerConsole implements ChatIF {

	private EchoServer server;
    private Scanner fromConsole;

    public ServerConsole(EchoServer server) {
        this.server = server;
        fromConsole = new Scanner(System.in);
    }

    public void accept() {
        try {
            String message;

            while (true) {
                message = fromConsole.nextLine();

                if (message.startsWith("#")) {
                    handleCommand(message);
                } else {
                    server.sendToAllClients("SERVER MSG> " + message);
                    System.out.println("SERVER MSG> " + message);
                }
            }
        } catch (Exception ex) {
            System.out.println("Unexpected error while reading from console!");
        }
    }
    
    private void handleCommand(String command) throws IOException {
        String[] parts = command.split(" ");
        String cmd = parts[0].toLowerCase();

        if (cmd.equals("#quit")) {
            handleQuit();
        } else if (cmd.equals("#stop")) {
            handleStop();
        } else if (cmd.equals("#close")) {
            handleClose();
        } else if (cmd.equals("#setport")) {
            handleSetPort(parts);
        } else if (cmd.equals("#start")) {
            handleStart();
        } else if (cmd.equals("#getport")) {
            handleGetPort();
        } else {
            System.out.println("Unknown command: " + cmd);
        }
    }
    
    private void handleQuit() {
        server.stopListening();
        System.exit(0);
    }

    private void handleStop() {
        server.stopListening();
    }

    private void handleClose() {
        server.closeAllConnections();
        server.stopListening();
    }

    private void handleSetPort(String[] parts) {
        if (parts.length < 2) {
            System.out.println("Error: Port number required.");
        } else if (server.isListening()) {
            System.out.println("Error: Must stop server before setting port.");
        } else {
            try {
                int port = Integer.parseInt(parts[1]);
                server.setPort(port);
                System.out.println("Port set to " + port);
            } catch (NumberFormatException e) {
                System.out.println("Error: Invalid port number.");
            }
        }
    }
    
    private void handleStart() throws IOException {
        if (server.isListening()) {
            System.out.println("Error: Server already listening.");
        } else {
            server.listen();
            System.out.println("Server listening on port " + server.getPort());
        }
    }

    private void handleGetPort() {
        System.out.println("Current port: " + server.getPort());
    }

    @Override
    public void display(String message) {
        System.out.println(message);
    }


}
