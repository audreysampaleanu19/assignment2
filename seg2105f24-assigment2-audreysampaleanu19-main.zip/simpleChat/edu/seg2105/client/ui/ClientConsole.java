package edu.seg2105.client.ui;
// This file contains material supporting section 3.7 of the textbook:
// "Object Oriented Software Engineering" and is issued under the open-source
// license found at www.lloseng.com 

import java.io.*;
import java.util.Scanner;

import edu.seg2105.client.backend.ChatClient;
import edu.seg2105.client.common.*;

/**
 * This class constructs the UI for a chat client.  It implements the
 * chat interface in order to activate the display() method.
 * Warning: Some of the code here is cloned in ServerConsole 
 *
 * @author Fran&ccedil;ois B&eacute;langer
 * @author Dr Timothy C. Lethbridge  
 * @author Dr Robert Lagani&egrave;re
 */
public class ClientConsole implements ChatIF 
{
  //Class variables *************************************************
  
  /**
   * The default port to connect on.
   */
  final public static int DEFAULT_PORT = 5555;
  
  //Instance variables **********************************************
  
  /**
   * The instance of the client that created this ConsoleChat.
   */
  ChatClient client;
  
  
  
  /**
   * Scanner to read from the console
   */
  Scanner fromConsole; 
  
  private String host = "localhost";
  private int port = DEFAULT_PORT;
  private boolean isConnected = false;
  private String loginId;
  
  
  

  
  //Constructors ****************************************************

  /**
   * Constructs an instance of the ClientConsole UI.
   *
   * @param host The host to connect to.
   * @param port The port to connect on.
   */
  public ClientConsole(String loginId, String host, int port) 
  {
	  this.loginId = loginId;
	  this.host = host;
      this.port = port;
      
      
    try 
    {
      client= new ChatClient(host, port, this,loginId);
      
      
    } 
    catch(IOException exception) 
    {
      System.out.println("Error: Can't setup connection!"
                + " Terminating client.");
      System.exit(1);
    }
    
    // Create scanner object to read from console
    fromConsole = new Scanner(System.in); 
  }

  
  //Instance methods ************************************************
  
  /**
   * This method waits for input from the console.  Once it is 
   * received, it sends it to the client's message handler.
   */
  public void accept() 
  {
    try
    {

      String message;

      while (true) 
      {
    	  message = fromConsole.nextLine();
    	  if (message.startsWith("#")) {
              handleCommand(message);
          } else {
              client.handleMessageFromClientUI(message);
          }
      }
    } 
    
    
    catch (Exception ex) 
    {
      System.out.println
        ("Unexpected error while reading from console");
    }
  }
  
  private void handleCommand(String command) {
      if (command.startsWith("#quit")) {
          quit();
      } 
      else if (command.startsWith("#logoff")) {
          logoff();
      } 
      else if (command.startsWith("#sethost")) {
          setHost(command);
      } 
      else if (command.startsWith("#setport")) {
          setPort(command);
      } 
      else if (command.startsWith("#login")) {
          login();
      } 
      else if (command.startsWith("#gethost")) {
          getHost();
      } 
      else if (command.startsWith("#getport")) {
          getPort();
      } 
      else {
          System.out.println("Invalid command: " + command);
      }
  }

  /**
   * This method overrides the method in the ChatIF interface.  It
   * displays a message onto the screen.
   *
   * @param message The string to be displayed.
   */
  public void display(String message) 
  {
    System.out.println("> " + message);
  }

  
  //Class methods ***************************************************
  
  
  
  private void quit() {
      if (isConnected) {
          client.quit(); 
      }
      System.exit(0);
  }

  private void logoff() {
      if (isConnected) {
          client.quit();
          isConnected = false;
          System.out.println("You have been logged out.");
      } else {
          System.out.println("You are disconnected.");
      }
  }

  private void setHost(String command) {
	  
	  String[] parts = command.split(" ");
	  if (parts.length < 2) {
          display("Error: Host name required.");
      } else if (client.isConnected()) {
          display("Error: Cannot change host while logged in.");
      } else {
    	 
          display("Host set to " + parts[1]);
      }
	
      
  }

  private void setPort(String command) {
	  String[] parts = command.split(" ");
      if (isConnected) {
          System.out.println("Error: Cannot change port while logged in.");
      } 
      else {
          if (parts.length == 2) {
              try {
                  port = Integer.parseInt(parts[1]);
                  System.out.println("Port set to: " + port);
              } catch (NumberFormatException e) {
                  System.out.println("Error: Invalid port number.");
              }
          } else {
              System.out.println("Error: Port number missing.");
          }
      }
  }

  private void login() {
      if (isConnected) {
          System.out.println("Already connected.");
      } else {
          try {
              client = new ChatClient(host, port, this, loginId);
              isConnected = true;
              System.out.println("A new client has connected to the server.");
              client.handleMessageFromClientUI("#login " + loginId);
          } catch (IOException e) {
              System.out.println("Error: Could not connect to server.");
          }
      }
  }

  private void getHost() {
      System.out.println("Current host: " + host);
  }

  private void getPort() {
      System.out.println("Current port: " + port);
  }

  
  /**
   * This method is responsible for the creation of the Client UI.
   *
   * @param args[0] The host to connect to.
   */
  public static void main(String[] args) 
  {
	  if (args.length < 1) {
          System.out.println("Usage: java ClientConsole <loginId> [host] [port]");
          System.exit(1);
      }

      String loginId = args[0];
      String host = args.length > 1 ? args[1] : "localhost";
      int port = args.length > 2 ? Integer.parseInt(args[2]) : DEFAULT_PORT;

      ClientConsole chat = new ClientConsole(loginId, host, port);
      chat.accept();
  }
  }
//End of ConsoleChat class
